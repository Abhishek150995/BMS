package com.garib.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.garib.bean.Customer;
import com.garib.service.AccountServiceImpl;

/**
 * Servlet implementation class LoginServlet
 */
/*@WebServlet(urlPatterns="/loginServlet")*/
public class LoginServlet extends HttpServlet {
	AccountServiceImpl ac= new AccountServiceImpl();


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		Customer c=ac.validateUser(username, password);
		if(c.equals(null))
		{
			request.setAttribute("Result", "Invalid data");
			RequestDispatcher dis=request.getRequestDispatcher("Login.jsp");
			dis.forward(request, response);
		}
		else
		{
			request.setAttribute("Result", c);
			RequestDispatcher dis=request.getRequestDispatcher("Dashboard.jsp");
			dis.forward(request, response);
		}
	}
	}


